var pantalla = document.getElementById('display');
var punto = 0;
function mostrarPantalla(arg) {
  var length = pantalla.outerText;
  if (parseInt(length) <= 9999999) {
    if (validar8Numero(length)) {
      if (parseFloat(pantalla.innerHTML) == 0) {
          if (arg == "punto") {
            pantalla.innerHTML = "0.";
            punto++;
          }else if(pantalla.innerHTML == "0.") pantalla.innerHTML += arg;
          else if(pantalla.innerHTML == "0") pantalla.innerHTML = arg;
            else pantalla.innerHTML += arg;
      }else {
        if (arg == "punto" && punto < 1) {
          pantalla.innerHTML += ".";
          punto++;
        }else{
          if (arg != "punto") pantalla.innerHTML += arg;
        }
      }
    }
  }else {
    alert("Solo se pueden ingresar 8 numeros");
  }
}

function validar8Numero(arg) {
    //debugger;
    var cadena = arg,
    separador = ".",
    arregloDeSubCadenas = cadena.split(separador);
    if (punto != 0) {
      var n = arregloDeSubCadenas[0].length;
      var m = String(arregloDeSubCadenas[1]).length;
      if (tieneSigno == true) n--;

      if ((n + m) < 8)
        return true;
      else
        return false;
    }else {
      var k = arg.length;
      if (tieneSigno == true) k--;
      if (k < 8)
        return true;
      else
        return false;
    }
}

function limpiarPantalla() {
  pantalla.innerHTML = "0";
  punto = 0;
  tieneSigno = false;
  ope = "";
  num1 = 0;
}

var tieneSigno = false;
function signoPantalla() {
  if (pantalla.innerHTML != 0) {
    var numero = pantalla.innerHTML * -1;
    pantalla.innerHTML = numero;
    if (numero > 0) tieneSigno = false;
    else tieneSigno = true;
  }
}

var ope = "";
var num1 = 0;
function operacion(arg) {
  ope = arg;
  num1 = pantalla.innerHTML;
  debugger;
  pantalla.innerHTML = "0";
  punto = 0;
  tieneSigno = false;

}

function resultadoPantalla() {
  debugger;
  var res = "";
  switch (ope) {
    case "division":
       res = String(parseFloat(num1)/parseFloat(pantalla.innerHTML));
       mostrar8Numeros(res);
      break;
    case "multiplicacion":
       res = String(parseFloat(pantalla.innerHTML) * parseFloat(num1));
       mostrar8Numeros(res);
      break;
    case "resta":
      res = String(parseFloat(num1) - parseFloat(pantalla.innerHTML));
      mostrar8Numeros(res);
      break;
    case "suma":
      res = String(parseFloat(num1) + parseFloat(pantalla.innerHTML));
      mostrar8Numeros(res);
      break;
    default:

  }
}

function mostrar8Numeros(res) {
  separador = "."
  seperar = res.split(separador);
  var n = seperar[0].length;
  var parte1 = res.substr(0, n);
  var parte2 = res.substr((n+1), (8-n))
  if (parte2 != "") {
    pantalla.innerHTML = (parte1+"."+parte2);
  }else {
      pantalla.innerHTML = (parte1+parte2);
  }

}
